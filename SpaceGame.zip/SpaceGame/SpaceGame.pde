// Brodden Spendlove | 9/16/26 | SpaceGame 
Ship ship01;

void setup() {
  ship01 = new Ship(width/2, height/2);
  size(650,600);
  
}

void draw() {
  background(20);
  ship01.move(mouseX, mouseY);
  ship01.display();
  
}
