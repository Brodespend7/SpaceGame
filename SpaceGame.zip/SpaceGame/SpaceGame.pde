// Brodden Spendlove | 9/16/26 | SpaceGame
ArrayList<EnemyShip> enemyships = new ArrayList<EnemyShip>();
ArrayList<Lazer> lazers = new ArrayList<Lazer>();
ArrayList<PowerUp> powups = new ArrayList<PowerUp>();
Ship ship01;
Timer eDist, puDist;

void setup() {
  frameRate(60);
  size(800, 1000);
  //enemyships.add(new EnemyShip(int(random(width)), -60));
  //powups.add(new PowerUp(int(random(width)), -60));
  ship01 = new Ship(width/2, height/2);
  eDist = new Timer(1000); // Time for the Timer
  puDist = new Timer(1000);
  puDist.start();
  eDist.start();
}
void draw() {
  noCursor();
  background(20);

  if (eDist.isFinished() == true) {
    // Spawn new EnemyShip
    enemyships.add(new EnemyShip(int(random(width)), -60));
    //Reset Time
    eDist.start();
  }

  // Add Power Ups
  if (puDist.isFinished() == true) {
    // spawn Power up
    powups.add(new PowerUp(int(random(width)), -60));
    // Reset Timer
    puDist.start;
  }

  for (int i = 0; i < powups.size(); i++) {
    println("Power Up:"+powups.size());
    PowerUp pu = powups.get(i);
    pu.display();
    pu.move();
    if (pu.isOffScreen() == true) {
      powups.remove(pu);
    }
  }

  for (PowerUp pu : powups) {
    pu.move();
    pu.display();

    ship01.move(mouseX, mouseY);
    ship01.display();
    // Displaying Lazers
    for (int i = 0; i < lazers.size(); i++) {
      println("Enemy Ships:"+lazers.size());
      Lazer l = lazers.get(i);
      l.display();
      l.move();
      if (l.isOffScreen() == true) {
        enemyships.remove(l);
      }
    }
  }
  for (int i = 0; i < enemyships.size(); i++) {
    println("Enemy Ships:"+enemyships.size());
    EnemyShip e = enemyships.get(i);
    e.display();
    e.move();
    if (e.isOffScreen() == true) {
      enemyships.remove(e);
    }
  }
}

void mousePressed() {
  lazers.add(new Lazer(ship01.x, ship01.y));
}
