class Ship {

  // member variables
  int x, y;
  PImage s1; // the Ships
  PImage a1; // the Aliens



  // constructor
  Ship(int x, int y) {
    this.x = x;
    this.y = y;
    s1 = loadImage("SpaceShip.png"); // Ship Image
    a1 = loadImage(""); // Alien image
  }

  // member methods
  void display() {
     imageMode(CENTER);
    image(s1,x,y);
    // image(a1,x,y);
    fill(50);
    //quad(x, y-90, x+40, y, x, y+30, x-40, y);
  }

  void move(int tempX, int tempY) {
    x = tempX;
    y = tempY;
  }
}
