class EnemyShip {
  // member variables
  int x, y, w, h, health, speed;//,damage,xp,currency;
  boolean isHit;
  PImage ES1;



  // Constructor
  EnemyShip(int x, int y) {
    this.x = x;
    this.y = y;
    w =  int(random(20, 100));
    h =  int(random(20, 100));
    speed =  int(random(1, 10));
    health = 100;
    isHit = false;
    ES1 = loadImage("");
  }


  // Member methods
  void display() {
    fill(235);
    ellipse(x, y, w, h);
    textAlign(CENTER, CENTER);
    fill(50);
    text(health, x, y);
  }

  void move() {
    y = y + speed;
  }

  boolean isOffScreen() {
    if (y>height+50) {
      return true;
    } else {
      return false;
    }
  }
}
