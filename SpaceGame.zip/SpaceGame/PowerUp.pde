class PowerUp {
  // member variables
  int x, y, size, speed;//,damage,xp,currency;
  char type;
  boolean isHit;
  PImage PU1;



  // Constructor
  PowerUp(int x, int y) {
    this.x = x;
    this.y = y;
    size =  int(random(20, 100));
    speed =  int(random(1, 10));
    if (random(2)>1.0) {
      type = 'h';
    } else {
      type = 't';
    }
    isHit = false;
    PU1 = loadImage("Piskel+1.png");
  }


  // Member methods
  void display() {
    fill(55, 200, 44);
    ellipse(x, y, size, size);
    textAlign(CENTER, CENTER);
    fill(50);
    text(type, x, y);
  }

  void move() {
    y = y + speed;
  }

  boolean isOffScreen() {
    if (y>height+50) {
      return true;
    } else {
      return false;
    }
  }
}
